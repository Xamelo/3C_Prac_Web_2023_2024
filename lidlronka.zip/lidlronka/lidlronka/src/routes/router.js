import {
  createBrowserRouter,
  redirect
} from "react-router-dom";

import App from "../App";
import Home from "../pages/Home";
import Products from "../pages/Products";
import ProductDetails from "../pages/ProductDetails";
import Cart from "../pages/Cart";
import Search from "../pages/Search";

import React, { Suspense } from "react";
const Admin = React.lazy(() => import("../pages/Admin"));

const fakeProducts = [
  { id: 1, name: "Chleb", category: "Pieczywo" },
  { id: 2, name: "Mleko", category: "Nabiał" },
  { id: 3, name: "Masło", category: "Nabiał" },
];

async function productsLoader() {
  return fakeProducts;
}

async function productDetailsLoader({ params }) {
  const product = fakeProducts.find((p) => p.id === +params.id);
  if (!product) throw new Response("Not Found", { status: 404 });
  return product;
}

async function cartAction({ request }) {
  const formData = await request.formData();
  const action = formData.get("action");
  const id = +formData.get("id");

  let cart = JSON.parse(localStorage.getItem("cart") || "[]");

  if (action === "add") {
    const product = fakeProducts.find((p) => p.id === id);
    if (product) {
      cart.push(product);
    }
  } else if (action === "remove") {
    cart = cart.filter((item) => item.id !== id);
  }

  localStorage.setItem("cart", JSON.stringify(cart));

  return { ok: true, cart };
}
async function adminLoader() {
  const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
  if (!isLoggedIn) {
    throw redirect("/login");
  }
  return { ok: true };
}

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    errorElement: <h2>Błąd</h2>,
    children: [
      { index: true, element: <Home /> },
      { path: "products", element: <Products />, loader: productsLoader },
      { path: "products/:id", element: <ProductDetails />, loader: productDetailsLoader },
      { path: "cart", element: <Cart />, action: cartAction },
      { path: "search", element: <Search />, loader: productsLoader },
      {
        path: "admin",
        loader: adminLoader,
        element: (
          <Suspense fallback={<p>Ładowanie panelu admina...</p>}>
            <Admin />
          </Suspense>
        ),
      },
    ],
  },
]);

export default router;