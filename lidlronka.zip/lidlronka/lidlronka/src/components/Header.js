export default function Header() {
  return <header><h1>Sklep Lidlronka</h1></header>;
}