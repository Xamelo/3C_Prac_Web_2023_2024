import { NavLink } from "react-router-dom";

export default function Navigation() {
  return (
    <nav className="nav nav-pills">
      <NavLink className="nav-link" to="/">Home</NavLink>
      <NavLink className="nav-link" to="/products">Produkty</NavLink>
      <NavLink className="nav-link" to="/cart">Koszyk</NavLink>
      <NavLink className="nav-link" to="/search">Szukaj</NavLink>
      <NavLink className="nav-link" to="/admin">Admin</NavLink>
    </nav>
  );
}