import { Outlet } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Navigation from "./components/Navigation";

function App() {
  return (
    <div className="container">
      <Header />
      <Navigation />
      <main className="lidlronka">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}

export default App;