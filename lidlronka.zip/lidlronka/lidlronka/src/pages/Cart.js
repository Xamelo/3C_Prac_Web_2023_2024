import { Form, useActionData, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";

export default function Cart() {
  const actionData = useActionData();
  const [cart, setCart] = useState(() =>
    JSON.parse(localStorage.getItem("cart") || "[]")
  );
  const navigate = useNavigate();

  useEffect(() => {
    if (actionData?.cart) {
      setCart(actionData.cart);
    }
  }, [actionData]);

  return (
    <div>
      <h2>Koszyk</h2>
      {cart.length === 0 ? (
        <p>Koszyk pusty</p>
      ) : (
        <ul>
          {cart.map((item) => (
            <li key={item.id}>
              {item.name} ({item.category})
              <Form method="post" action="/cart" style={{ display: "inline" }}>
                <input type="hidden" name="id" value={item.id} />
                <button type="submit" name="action" value="remove">
                  Usuń
                </button>
              </Form>
            </li>
          ))}
        </ul>
      )}
      <button onClick={() => navigate("/products")}>Wróć do produktów</button>
    </div>
  );
}