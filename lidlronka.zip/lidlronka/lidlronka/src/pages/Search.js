import { useLoaderData, useSearchParams, Link } from "react-router-dom";

export default function Search() {
  const products = useLoaderData();
  const [params, setParams] = useSearchParams();
  const q = params.get("q")?.toLowerCase() || "";

  const results = q
    ? products.filter((p) => p.name.toLowerCase().includes(q))
    : [];

  return (
    <div>
      <h2>Szukaj produktów</h2>

      <input
        value={q}
        onChange={(e) => setParams({ q: e.target.value })}
        placeholder="Wpisz nazwę produktu..."
      />

      {q && (
        <div>
          <h3>Wyniki dla: "{q}"</h3>
          {results.length === 0 ? (
            <p>Brak wyników</p>
          ) : (
            <ul>
              {results.map((p) => (
                <li key={p.id}>
                  <Link to={`/products/${p.id}`}>{p.name}</Link> ({p.category})
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
