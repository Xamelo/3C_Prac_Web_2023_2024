import { useState } from "react";

export default function Home() {
  const [isLogged, setIsLogged] = useState(localStorage.getItem("isLoggedIn") === "true");

  const handleLogin = () => {
    localStorage.setItem("isLoggedIn", "true");
    setIsLogged(true);
  };

  const handleLogout = () => {
    localStorage.setItem("isLoggedIn", "false");
    setIsLogged(false);
  };

  return (
    <div>
      <h2>Sklep Lidlronka</h2>
      {isLogged ? (
        <>
          <p>Zalogowany admin</p>
          <button onClick={handleLogout}>Wyloguj</button>
        </>
      ) : (
        <>
          <p>Wylogowany admin</p>
          <button onClick={handleLogin}>Zaloguj</button>
        </>
      )}
    </div>
  );
}