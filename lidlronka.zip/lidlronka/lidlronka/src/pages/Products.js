import { useLoaderData, Link } from "react-router-dom";
import { useState } from "react";

export default function Products() {
  const products = useLoaderData();
  const [filter, setFilter] = useState("");

  const filtered = filter
    ? products.filter((p) => p.category === filter)
    : products;

  return (
    <div>
      <h2>Lista produktów</h2>
      <div>
        <label>
          <input type="radio" name="category" checked={filter === ""} onChange={() => setFilter("")}/> Wszystko
        </label>
        <label>
          <input type="radio" name="category" checked={filter === "Nabiał"} onChange={() => setFilter("Nabiał")}/> Nabiał
        </label>
        <label>
          <input type="radio" name="category" checked={filter === "Pieczywo"} onChange={() => setFilter("Pieczywo")}/> Pieczywo
        </label>
      </div>

      <ul>
        {filtered.map((p) => (
          <li key={p.id}>
            <Link to={`/products/${p.id}`}>{p.name}</Link> ({p.category})
          </li>
        ))}
      </ul>
    </div>
  );
}