import { useLoaderData, Form } from "react-router-dom";

export default function ProductDetails() {
  const product = useLoaderData();

  return (
    <div>
      <h2>Szczegóły produktu</h2>
      <p><strong>{product.name}</strong></p>
      <p>Kategoria: {product.category}</p>

      <Form method="post" action="/cart">
        <input type="hidden" name="id" value={product.id} />
        <button type="submit" name="action" value="add">Dodaj do koszyka</button>
      </Form>
    </div>
  );
} 